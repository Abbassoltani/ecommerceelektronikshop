

function Banner() {



  const bannerImage = [
    '/public/assets/ai1.png',
    '/public/assets/ai2.png',
    '/public/assets/ai3.png',
    '/public/assets/ai4.png',
    '/public/assets/ai5.png',
  ]


  return (
    <>
      <div className="banner d-flex ">

        {bannerImage.map(img => (
          <>
            <div className=" bannerr  " >

              <img src={img} alt="" className='img-fluid banner-img' />

            </div>
          </>
        ))}

      </div>

    </>
  )
}

export default Banner
