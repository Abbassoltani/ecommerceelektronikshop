
import React from 'react'
import ItemCard from '../components/ItemCard'

function Wishlist() {
  
  return (
    <>
    <div className="col-12 col-md-4 col-lg-4 gap-1">
      {/* <ItemCard/>
    */}
    </div>
    
  
    </>
  )
}

export default Wishlist
